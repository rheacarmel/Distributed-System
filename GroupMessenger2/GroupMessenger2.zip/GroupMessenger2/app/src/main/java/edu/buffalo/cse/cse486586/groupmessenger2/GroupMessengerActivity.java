package edu.buffalo.cse.cse486586.groupmessenger2;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.OptionalDataException;
import java.io.Serializable;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Collections;

import static android.content.ContentValues.TAG;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 * 
 * @author stevko
 *
 */
public class GroupMessengerActivity extends Activity {
    private Uri providerUri;
    static  final int SERVER_PORT=10000;
    static final String REMOTE_PORT1="11108";
    static final String REMOTE_PORT2="11112";
    static final String REMOTE_PORT3="11116";
    static  final String REMOTE_PORT4="11120";
    static  final String REMOTE_PORT5="11124";
    static  double a[]=new double[5];
    double counter=0.0;

    double proposed__counter=0.0;
    double final__counter=0.0;
    double Final_counter;
    PriorityQueue<App_message>Pqueue=new PriorityQueue<App_message>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);

        /*
         * TODO: Use the TextView to display your messages. Though there is no grading component
         * on how you display the messages, if you implement it, it'll make your debugging easier.
         */
        TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        
        /*
         * Registers OnPTestClickListener for "button1" in the layout, which is the "PTest" button.
         * OnPTestClickListener demonstrates how to access a ContentProvider.
         */
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));
        
        /*
         * TODO: You need to register and implement an OnClickListener for the "Send" button.
         * In your implementation you need to get the message from the input box (EditText)
         * and send it to other AVDs.
         */

        for(int i=0;i<5;i++){
            a[i]=0;
        }
        TelephonyManager tel = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));


        try{


            ServerSocket serverSocket= new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,serverSocket);
        } catch (IOException e) {
            Log.e(TAG, "cannot create server ");
        }

        final EditText editText= (EditText) findViewById(R.id.editText1);
        Button button=(Button)findViewById(R.id.button4);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg=editText.getText().toString();
                editText.setText("");
                TextView textView= (TextView)findViewById(R.id.textView1);
                // textView.append(msg);
                //textView.append("\n");

                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR,msg,myPort);

            }
        });
    }

    int count;
    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {
        @Override
        protected Void doInBackground(ServerSocket... serverSockets) {
            int seq=0;
            Log.i(TAG, "initial seq"+seq);
            ServerSocket serverSocket = serverSockets[0];


            try {
                proposed__counter=0.0;
                final__counter=0.0;

                while (true) {




                    Socket clientSocket = serverSocket.accept();
                    ObjectOutputStream ds1=new ObjectOutputStream(clientSocket.getOutputStream());
                    ObjectInputStream ir = new ObjectInputStream(new BufferedInputStream(clientSocket.getInputStream()));


                  /*  ds1.writeUTF(Double.toString(seq));
                    Log.i(TAG, "seq in double "+seq);
                    String msg="";*/
                    //msg = ir.readUTF();
                    App_message server_message=new App_message();
                    server_message= (App_message) ir.readObject();

                    if(server_message.getFinal_counter()==0.0) {

                        server_message.setSeq(seq);
                        Log.i(TAG, "seq set " + seq);
                        seq = seq + 1;

                        if (proposed__counter <= final__counter) {
                            proposed__counter = (int) final__counter + server_message.getServer_number() + 1;
                            Log.i(TAG, "int final counter "+(int)final__counter);
                        } else {
                            proposed__counter = proposed__counter + server_message.getServer_number() + 1;
                        }
                        Log.i(TAG, "proposed counter is" + proposed__counter);


                        //Iterator g_iterator = Pqueue.iterator();

                        Log.i(TAG, "server number " + server_message.getServer_number());
                        // new Sequence proposed
                        //if()
                        //proposed__counter=server_message.getCounter()+server_message.getServer_number();
                        //  Log.i(TAG, "local port number "+ Double.toString(proposed__counter));

                        //if (proposed__counter>server_message.getCounter()){
                        server_message.setCounter(proposed__counter);
                        Pqueue.add(server_message);
                        ds1.writeObject(server_message);
                        Log.i(TAG, "proposed sequence sent from server " + proposed__counter);


                    }
                    else if(server_message.getFinal_counter()!=0.0 ) {

                        App_message final_message;


                        //  final_message= (App_message) ir.readObject();//recieve the message
                        //server_message = (App_message) ir.readObject();
                        Log.i(TAG, "the proposed from client counter is " + server_message.getFinal_counter());
                        final__counter=server_message.getFinal_counter();
                        Iterator it = Pqueue.iterator();   //make an iterator and send the message
                        App_message queue_message;
                        while (it.hasNext()) {

                            queue_message = (App_message) it.next();
                            if (queue_message.getCounter() == server_message.getCounter()) {
                                Pqueue.remove(queue_message);
                                Log.i(TAG, "final counter in queue is"+final__counter);
                                queue_message.setCounter(server_message.getFinal_counter());
                                queue_message.setDeliverable(true);
                                Pqueue.add(queue_message);
                                Log.i(TAG, "the final queue" + Pqueue.toString());
                            } else {
                                continue;
                            }
                        }




                            /* or
                             * for (App_message App:Pqueue){
                             * if App.getCounter()==final_message.getCounter()
                             * {
                             *      Pqueue.remove(App)
                             *      App.setCounter(final_message.getFinal_counter());
                             *      Pqueue.add(App)
                             * }
                             * }*/


                          App_message first= Pqueue.peek();
                          while(first!=null)
                          {   first=Pqueue.poll();
                              String msg=first.getMessage()+":"+first.getSeq();
                              publishProgress(msg);
                              first=Pqueue.peek();
                          }
                      }





                }






                   /* String new_key=ir.readUTF();
                    Log.i(TAG, "sequence from sender"+new_key);
                    seq=Double.parseDouble(new_key);
                    Log.i(TAG, "sequence in the queue"+seq);
                    Map<Double,String>hash=new HashMap<Double, String>();
                    hash.put(seq,msg);

                    PriorityQueue<Map.Entry<Double,String>> Pqueue= new PriorityQueue<Map.Entry<Double, String>>(5, new Comparator<Map.Entry<Double, String>>() {
                        @Override
                        public int compare(Map.Entry<Double, String> lhs, Map.Entry<Double, String> rhs) {
                            return rhs.getKey().compareTo(lhs.getKey());
                        }
                    });
                    for(Map.Entry<Double,String>entry:hash.entrySet()) {
                        Pqueue.offer(entry);
                        Log.i(TAG, "entry in priority queue  successful");
                    }
                    int new_seq;
                    new_seq=(int)seq;
                    seq=new_seq+1.0;

                    Log.i(TAG,Arrays.toString(Pqueue.toArray()));
                   /* if(Pqueue.contains(msg)==true)
                    {

                    }*/

                        // Log.i(TAG, "new key is processor is"+new_key);
                  /*  Log.i(TAG, "new Sequence is "+seq);

                    count=count+1;
                    msg=msg+":"+Integer.toString(count);
                    */
                        // Log.i(TAG, "server message"+server_message.getMessage());
                        //publishProgress(server_message.getMessage((int) server_message.getCounter()));

                } catch (OptionalDataException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            }


            return null;
        }


        protected void onProgressUpdate(String...strings) {
            String [] message=strings[0].split(":");
             String strReceived = message[0].trim();

            Log.i(TAG, "message count "+message[1]);
            TextView textView = (TextView) findViewById(R.id.textView1);
            textView.append(strReceived +"\t\n");

            providerUri = buildUri("content", "edu.buffalo.cse.cse486586.groupmessenger2.provider");
            ContentValues keyValueToInsert = new ContentValues();


            // inserting <”key-to-insert”, “value-to-insert”>
            keyValueToInsert.put("key",Integer.toString(count));
            //keyValueToInsert.put("key",message[1]);
            keyValueToInsert.put("value",strReceived);

            Uri newUri = getContentResolver().insert(
                    providerUri,    // assume we already created a Uri object with our provider URI using uribuilder
                    keyValueToInsert
            );
            count=count+1;
            Log.i(TAG, "inserted"+newUri.toString());

            //count=count+1;


            Log.i(TAG, "onProgressUpdate: string recieved"+strReceived);

        }


        private Uri buildUri(String scheme, String authority) {
            Uri.Builder uriBuilder = new Uri.Builder();
            uriBuilder.authority(authority);
            uriBuilder.scheme(scheme);
            return uriBuilder.build();
        }
    }


    private  class ClientTask extends  AsyncTask<String,Void,Void>{
        @Override
        protected Void doInBackground(String... strings) {

            //String remotePort= REMOTE_PORT1;
            //  if (strings[1].equals(REMOTE_PORT1)){



            try {

                String msgToSend = strings[0];
                //counter=counter+1;
                App_message app_message = new App_message();
                // app_message.setCounter(counter);
                app_message.setMessage(msgToSend);
                app_message.setDeliverable(false);

                //Log.i(TAG, "doInBackground: "+remotePort);
                Socket socket1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT1));
                Socket socket2 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT2));
                Socket socket3 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT3));
                Socket socket4 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT4));
                Socket socket5 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT5));
                //String msgToSend=strings[0];

                //send message to  lets make a class for send_message

                ObjectOutputStream ds1 = new ObjectOutputStream(socket1.getOutputStream());

                app_message.setServer_number(0.0);
                ds1.writeObject(app_message);
                ds1.flush();

                ObjectOutputStream ds2 = new ObjectOutputStream(socket2.getOutputStream());

                app_message.setServer_number(0.1);
                ds2.writeObject(app_message);
                ds2.flush();

                ObjectOutputStream ds3 = new ObjectOutputStream(socket3.getOutputStream());

                app_message.setServer_number(0.2);
                ds3.writeObject(app_message);
                ds3.flush();

                ObjectOutputStream ds4 = new ObjectOutputStream(socket4.getOutputStream());

                app_message.setServer_number(0.3);
                ds4.writeObject(app_message);
                ds4.flush();

                ObjectOutputStream ds5 = new ObjectOutputStream(socket5.getOutputStream());

                app_message.setServer_number(0.4);
                ds5.writeObject(app_message);
                ds5.flush();

                // get the message priority counter from server
                try {
                    App_message new_message;
                    ObjectInputStream ir1 = new ObjectInputStream(new BufferedInputStream(socket1.getInputStream()));
                    // double value1=ir1.read()+0.1;

                    new_message = (App_message) ir1.readObject();
                    a[0] = new_message.getCounter();
                    Log.i(TAG, "server 0" + a[0]);

                    ObjectInputStream ir2 = new ObjectInputStream(new BufferedInputStream(socket2.getInputStream()));
                    new_message = (App_message) ir2.readObject();
                    a[1] = new_message.getCounter();
                    Log.i(TAG, "server 1 " + a[1]);

                    ObjectInputStream ir3 = new ObjectInputStream(new BufferedInputStream(socket3.getInputStream()));
                    // double value1=ir1.read()+0.1;
                    new_message = (App_message) ir3.readObject();
                    a[2] = new_message.getCounter();
                    Log.i(TAG, "server 2 " + a[2]);


                    ObjectInputStream ir4 = new ObjectInputStream(new BufferedInputStream(socket4.getInputStream()));
                    // double value1=ir1.read()+0.1;
                    new_message = (App_message) ir4.readObject();
                    a[3] = new_message.getCounter();
                    Log.i(TAG, "server 3 " + a[3]);

                    ObjectInputStream ir5 = new ObjectInputStream(new BufferedInputStream(socket5.getInputStream()));
                    // double value1=ir1.read()+0.1;

                    new_message = (App_message) ir5.readObject();
                    a[4] = new_message.getCounter();
                    Log.i(TAG, "server 4 " + a[4]);
                } catch (OptionalDataException ex) {
                    ex.printStackTrace();
                } catch (IOException ex) {
                    ex.printStackTrace();
                } catch (ClassNotFoundException ex) {
                    ex.printStackTrace();
                }


                if (a.length == 5) {
                    // get the proposed value from the server
                    Arrays.sort(a);
                    Final_counter = a[a.length - 1];
                    Log.i(TAG, "the final counter is" + Final_counter);


                    App_message new_app_message = new App_message();
                    new_app_message.setFinal_counter(Final_counter);
                    //Log.i(TAG, "app_message.getFinal_Counter ="+app_message.getFinal_counter());
                    new_app_message.setDeliverable(true);


                    Socket socket6 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT1));
                    Socket socket7 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT2));
                    Socket socket8 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT3));
                    Socket socket9 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT4));
                    Socket socket10 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT5));

                    //app_message.setServer_number(0.0);

                    ObjectOutputStream ds6 = new ObjectOutputStream(socket6.getOutputStream());
                    ds6.writeObject(new_app_message);
                    ds6.flush();


                    //app_message.setServer_number(0.1);
                    ObjectOutputStream ds7 = new ObjectOutputStream(socket7.getOutputStream());
                    ds7.writeObject(new_app_message);
                    ds7.flush();


                    //app_message.setServer_number(0.2);
                    ObjectOutputStream ds8 = new ObjectOutputStream(socket8.getOutputStream());
                    ds8.writeObject(new_app_message);
                    ds8.flush();

                    ObjectOutputStream ds9 = new ObjectOutputStream(socket9.getOutputStream());

                    ds9.writeObject(new_app_message);
                    ds9.flush();


                    ObjectOutputStream ds10 = new ObjectOutputStream(socket10.getOutputStream());
                    ds10.writeObject(new_app_message);
                    ds10.flush();

                  }
                } catch(UnknownHostException e){
                    e.printStackTrace();
                } catch(IOException e){
                    e.printStackTrace();
                }

                //send the final count






            return null;
        }




    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }
}


class App_message implements  Serializable,Comparable<App_message>{
    int seq;
    double counter;
    double final_counter=0.0;
    String message;
    Boolean deliverable= Boolean.FALSE;
    double server_number;

    public void setServer_number(double server_number) {
        this.server_number = server_number;
    }

    public void setFinal_counter(double final_counter) {
        this.final_counter = final_counter;
    }

    public double getServer_number() {
        return server_number;
    }

    public Boolean getDeliverable() {
        return deliverable;
    }

    public int getSeq() {
        return seq;
    }

    public void setCounter(double counter) {
        this.counter = counter;
    }

    public double getFinal_counter() {
        return final_counter;
    }

    public double getCounter() {
        return counter;
    }
    public void setMessage(String message){
        this.message=message;
    }

    public String getMessage() {
        //if(counter==this.counter)
            return message;
        //else{
          //  return null;

        //s}
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }

    public void setDeliverable(Boolean deliverable) {
        this.deliverable = deliverable;
    }

    @Override
    public int compareTo(App_message another) {
        if (this.getCounter() > another.getCounter()) {
            return 1;
        } else if (this.getCounter() < another.getCounter()) {
            return -1;
        } else {
            return 0;
        }
    }
}
